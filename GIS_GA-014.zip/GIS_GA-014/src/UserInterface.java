import javax.swing.SwingUtilities;
import java.awt.BorderLayout;

import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;

import java.awt.GridBagLayout;
import java.awt.Dimension;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import java.awt.GridBagConstraints;
import java.awt.Rectangle;
import java.awt.Point;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.CardLayout;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.BorderFactory;
import javax.swing.border.TitledBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.FlowLayout;
import java.awt.Color;

public class UserInterface extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	
	/**
	  * @author : SUGIARTO COKROWIBOWO
	  * @author sugiartocokrowibowo@gmail.com
	  * @author +62852 5555 7738
	 **/
	
	private SCWPanel jPanel = null;
	private JPanel jPanel1 = null;
	private JTextField jTextField1 = null;
	private JTextField jTextField2 = null;
	private JTextField jTextField3 = null;
	private JTextField jTextField4 = null;
	private JTextField jTextField5 = null;
	private JTextField jTextField6 = null;
	private JTextField jTextField7 = null;
	private JTextField jTextField8 = null;
	private JTextField jTextField9 = null;
	private JTextField jTextField10 = null;
	private JTextField jTextField0 = null;
	private JButton jButton1 = null;
	private JButton jButton2 = null;
	private JButton jButton3 = null;
	private JPanel jPanel2 = null;
	private JScrollPane jScrollPane = null;
	private JTextArea jTextArea = null;
	private JFileChooser openFile_dialog = null;
	private CardLayout cardLayout	= null;  //  @jve:decl-index=0:
	private File filecsvin				= null;
	private File filecsvout				= new File("output.csv");  //  @jve:decl-index=0:
	private double[][]data				= null;
	private int numFasilitas			= 10;
	private int numIndividu				= 10;
	private int numGenerasi				= 20;
	private int numIndividuTerseleksi	= 6;
	private int numCrossOverPoint		= 6;
	private double probabilitasMutasi	= 0.5;
	private double l					= 100;
	private double A0					= 120;
	private double k					= 7;
	private double CLamda				= 1;
	private JPanel jPanel3 = null;
	private JButton jButton4 = null;

	/**
	 * This method initializes jPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private SCWPanel getJPanel() {
		if (jPanel == null) {
			jPanel = new SCWPanel(getClass().getResource("/res/texture_6.png"));
			jPanel.resized	=  true;
			jPanel.setOpaque(false);
			this.cardLayout	= new CardLayout();
			jPanel.setLayout(this.cardLayout);
			jPanel.add(getJPanel1(), "1");
			jPanel.add(getJPanel2(), "2");
		}
		return jPanel;
	}

	/**
	 * This method initializes jPanel1	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel1() {
		if (jPanel1 == null) {
			jPanel1 = new SCWPanel(getClass().getResource("/res/bg0.png"));
			jPanel1.setOpaque(false);
			jPanel1.setLayout(null);
			jPanel1.setName("jPanel1");
			jPanel1.add(getJTextField0(), null);
			jPanel1.add(getJTextField1(), null);
			jPanel1.add(getJTextField2(), null);
			jPanel1.add(getJTextField3(), null);
			jPanel1.add(getJTextField4(), null);
			jPanel1.add(getJTextField5(), null);
			jPanel1.add(getJTextField6(), null);
			jPanel1.add(getJTextField7(), null);
			jPanel1.add(getJTextField8(), null);
			jPanel1.add(getJTextField9(), null);
			jPanel1.add(getJTextField10(), null);
			jPanel1.add(getJButton1(), null);
			jPanel1.add(getJButton2(), null);
			jPanel1.add(getJButton3(), null);
		}
		return jPanel1;
	}

	/**
	 * This method initializes jTextField1	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextField1() {
		if (jTextField1 == null) {
			jTextField1 = new JTextField();
			jTextField1.setLocation(new Point(752, 102));
			jTextField1.setText(""+numFasilitas);
			jTextField1.setSize(new Dimension(180, 40));
		}
		return jTextField1;
	}

	/**
	 * This method initializes jTextField2	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextField2() {
		if (jTextField2 == null) {
			jTextField2 = new JTextField();
			jTextField2.setLocation(new Point(770, 162));
			jTextField2.setText(""+numIndividu);
			jTextField2.setSize(new Dimension(180, 40));
		}
		return jTextField2;
	}

	/**
	 * This method initializes jTextField3	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextField3() {
		if (jTextField3 == null) {
			jTextField3 = new JTextField();
			jTextField3.setLocation(new Point(782, 222));
			jTextField3.setText(""+numGenerasi);
			jTextField3.setSize(new Dimension(180, 40));
		}
		return jTextField3;
	}

	/**
	 * This method initializes jTextField4	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextField4() {
		if (jTextField4 == null) {
			jTextField4 = new JTextField();
			jTextField4.setLocation(new Point(785, 282));
			jTextField4.setText(""+numIndividuTerseleksi);
			jTextField4.setSize(new Dimension(180, 40));
		}
		return jTextField4;
	}

	/**
	 * This method initializes jTextField5	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextField5() {
		if (jTextField5 == null) {
			jTextField5 = new JTextField();
			jTextField5.setLocation(new Point(789, 342));
			jTextField5.setText(""+numCrossOverPoint);
			jTextField5.setSize(new Dimension(180, 40));
		}
		return jTextField5;
	}

	/**
	 * This method initializes jTextField6	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextField6() {
		if (jTextField6 == null) {
			jTextField6 = new JTextField();
			jTextField6.setLocation(new Point(785, 400));
			jTextField6.setText(""+probabilitasMutasi);
			jTextField6.setSize(new Dimension(180, 40));
		}
		return jTextField6;
	}

	/**
	 * This method initializes jTextField7	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextField7() {
		if (jTextField7 == null) {
			jTextField7 = new JTextField();
			jTextField7.setLocation(new Point(780, 460));
			jTextField7.setText(""+l);
			jTextField7.setSize(new Dimension(180, 40));
		}
		return jTextField7;
	}

	/**
	 * This method initializes jTextField8	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextField8() {
		if (jTextField8 == null) {
			jTextField8 = new JTextField();
			jTextField8.setLocation(new Point(769, 520));
			jTextField8.setText(""+A0);
			jTextField8.setSize(new Dimension(180, 40));
		}
		return jTextField8;
	}

	/**
	 * This method initializes jTextField9	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextField9() {
		if (jTextField9 == null) {
			jTextField9 = new JTextField();
			jTextField9.setLocation(new Point(752, 580));
			jTextField9.setText(""+k);
			jTextField9.setSize(new Dimension(180, 40));
		}
		return jTextField9;
	}

	/**
	 * This method initializes jTextField10	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextField10() {
		if (jTextField10 == null) {
			jTextField10 = new JTextField();
			jTextField10.setLocation(new Point(729, 640));
			jTextField10.setText(""+CLamda);
			jTextField10.setSize(new Dimension(180, 40));
		}
		return jTextField10;
	}

	/**
	 * This method initializes jTextField0	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextField0() {
		if (jTextField0 == null) {
			jTextField0 = new JTextField();
			jTextField0.setLocation(new Point(358, 42));
			jTextField0.setSize(new Dimension(353, 40));
		}
		return jTextField0;
	}

	/**
	 * This method initializes jButton1	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton1() {
		if (jButton1 == null) {
			jButton1 = new JButton();
			jButton1.setFocusPainted(false);
			jButton1.setBorderPainted(false);
			jButton1.setContentAreaFilled(false);
			jButton1.setLocation(new Point(716, 35));
			jButton1.setSize(new Dimension(83, 53));
			jButton1.setIcon(new ImageIcon(getClass().getResource("/res/button_cari1.png")));
			jButton1.setRolloverIcon(new ImageIcon(getClass().getResource("/res/button_cari2.png")));
			jButton1.setDisabledIcon(new ImageIcon(getClass().getResource("/res/button_cari3.png")));
			jButton1.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					browseFile();
					jButton2.setEnabled(true);
					jButton3.setEnabled(false);
					System.out.println("actionPerformed()"); // TODO Auto-generated Event stub actionPerformed()
				}
			});
			jButton1.setContentAreaFilled(false);
		}
		return jButton1;
	}

	/**
	 * This method initializes jButton2	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton2() {
		if (jButton2 == null) {
			jButton2 = new JButton();
			jButton2.setContentAreaFilled(false);
			jButton2.setFocusPainted(false);
			jButton2.setBorderPainted(false);
			jButton2.setDisabledIcon(new ImageIcon(getClass().getResource("/res/button_run3.png")));
			jButton2.setIcon(new ImageIcon(getClass().getResource("/res/button_run1.png")));
			jButton2.setRolloverIcon(new ImageIcon(getClass().getResource("/res/button_run2.png")));
			jButton2.setLocation(new Point(799, 35));
			jButton2.setSize(new Dimension(83, 53));
			jButton2.setEnabled(false);
			jButton2.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					runGA();
					jButton3.setEnabled(true);
					System.out.println("actionPerformed()"); // TODO Auto-generated Event stub actionPerformed()
				}
			});
		}
		return jButton2;
	}

	/**
	 * This method initializes jButton3	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton3() {
		if (jButton3 == null) {
			jButton3 = new JButton();
			jButton3.setContentAreaFilled(false);
			jButton3.setFocusPainted(false);
			jButton3.setBorderPainted(false);
			jButton3.setDisabledIcon(new ImageIcon(getClass().getResource("/res/button_hasil3.png")));
			jButton3.setIcon(new ImageIcon(getClass().getResource("/res/button_hasil1.png")));
			jButton3.setRolloverIcon(new ImageIcon(getClass().getResource("/res/button_hasil2.png")));
			jButton3.setLocation(new Point(882, 35));
			jButton3.setSize(new Dimension(83, 53));
			jButton3.setEnabled(false);
			jButton3.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					cardLayout.show(jPanel, "2");
					System.out.println("actionPerformed()"); // TODO Auto-generated Event stub actionPerformed()
				}
			});
		}
		return jButton3;
	}

	/**
	 * This method initializes jPanel2	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel2() {
		if (jPanel2 == null) {
			jPanel2 = new JPanel();
			jPanel2.setLayout(new BorderLayout());
			jPanel2.setName("jPanel2");
			jPanel2.setOpaque(false);
			jPanel2.add(getJScrollPane(), BorderLayout.CENTER);
			jPanel2.add(getJPanel3(), BorderLayout.SOUTH);
		}
		return jPanel2;
	}

	/**
	 * This method initializes jScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPane() {
		if (jScrollPane == null) {
			jScrollPane = new JScrollPane();
			jScrollPane.setBorder(BorderFactory.createTitledBorder(null, "Result GIS Genetic Algorithm", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.DEFAULT_POSITION, null, Color.white));
			jScrollPane.setViewportView(getJTextArea());
		}
		return jScrollPane;
	}

	/**
	 * This method initializes jTextArea	
	 * 	
	 * @return javax.swing.JTextArea	
	 */
	private JTextArea getJTextArea() {
		if (jTextArea == null) {
			jTextArea = new JTextArea();
		}
		return jTextArea;
	}

	/**
	 * This method initializes jPanel3	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel3() {
		if (jPanel3 == null) {
			jPanel3 = new JPanel();
			jPanel3.setLayout(new FlowLayout());
			jPanel3.setOpaque(false);
			jPanel3.add(getJButton4(), null);
		}
		return jPanel3;
	}

	/**
	 * This method initializes jButton4	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton4() {
		if (jButton4 == null) {
			jButton4 = new JButton();
			jButton4.setContentAreaFilled(false);
			jButton4.setDisabledIcon(new ImageIcon(getClass().getResource("/res/button_back3.png")));
			jButton4.setFocusPainted(false);
			jButton4.setIcon(new ImageIcon(getClass().getResource("/res/button_back1.png")));
			jButton4.setRolloverIcon(new ImageIcon(getClass().getResource("/res/button_back2.png")));
			jButton4.setPreferredSize(new Dimension(83, 53));
			jButton4.setBorderPainted(false);
			jButton4.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					cardLayout.show(jPanel, "1");
					System.out.println("actionPerformed()"); // TODO Auto-generated Event stub actionPerformed()
				}
			});
		}
		return jButton4;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				UserInterface thisClass = new UserInterface();
				thisClass.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				thisClass.setVisible(true);
			}
		});
	}

	/**
	 * This is the default constructor
	 */
	public UserInterface() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		try {
			//UIManager.setLookAndFeel(ch.randelshofer.quaqua.QuaquaManager.getLookAndFeel());
			for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
		        if ("Nimbus".equals(info.getName())) {
		            UIManager.setLookAndFeel(info.getClassName());
		            break;
		        }
		    }
        } catch (Exception e) {}
        
        this.openFile_dialog		= new JFileChooser();
		//FileNameExtensionFilter filter = new FileNameExtensionFilter("CSV File", "csv", "xlsx");
		FileNameExtensionFilter filter = new FileNameExtensionFilter("CSV File", "csv");
		openFile_dialog.setFileFilter(filter);
        this.setSize(1036, 730);
        this.setIconImage(new ImageIcon(getClass().getResource("/res/logo.png")).getImage());
		this.setContentPane(getJContentPane());
		this.setTitle("GIS Genetic Algorithm + info iterasi");
		this.setLocationRelativeTo(null);
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setOpaque(false);
			jContentPane.setLayout(new BorderLayout());
			jContentPane.add(getJPanel(), BorderLayout.CENTER);
		}
		return jContentPane;
	}
	
	private void browseFile(){
		int hasil = openFile_dialog.showOpenDialog(this);
		if(hasil==JFileChooser.APPROVE_OPTION){
			File file		=openFile_dialog.getSelectedFile();
			filecsvin			= file;
			this.data		= readCSVfile(file);
			jTextField0.setText(file.toString());			
		}//end of if
	}//end of browseFile
	
	private double[][]readCSVfile(File file){
		double[][]data	= null;
		if(file!=null){
			try {
				FileReader fr		= new FileReader(file);
				BufferedReader br 	= new BufferedReader(fr);
				String line = "";
				String cvsSplitBy = ",";
				line = br.readLine();
				ArrayList<String>sData	= new ArrayList<String>();
				while ((line = br.readLine()) != null) {
					sData.add(line);
				}
				if(sData.size()>0){
					//x y penduduk D_roads Fasilitas FID_1*/
					data	= new double[sData.size()][6];
					for(int i=0;i<data.length;i++){
						//gunakan comma (,) sebagai pemisah nilai
						String[] value = sData.get(i).split(cvsSplitBy);
						data[i][0]	= Double.parseDouble(value[1]);
						data[i][1]	= Double.parseDouble(value[2]);
						data[i][2]	= Double.parseDouble(value[4]);
						data[i][3]	= Double.parseDouble(value[5]);
						data[i][4]	= Double.parseDouble(value[6]);
						data[i][5]	= Double.parseDouble(value[7]);
					}
				}	
				br.close();
				fr.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return data;
	}
	
	private void runGA(){

		jButton1.setEnabled(false);
		jButton2.setEnabled(false);
		jButton3.setEnabled(false);
		
		bacaParameter();
		GA ga						= new GA(this.data, this.numFasilitas, this.numIndividu, this.numGenerasi, this.numIndividuTerseleksi, this.numCrossOverPoint, this.probabilitasMutasi, this.l, this.A0, this.k, this.CLamda);
		//menampilkan hasil komputasi di text area
		jTextArea.setText("INFO HASIL KOMPUTASI ALGORITMA GENETIKA\n");
		jTextArea.append("-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- \n");
		jTextArea.append("Banyaknya Simpul: "+ga.getNumVertex()+"\n");
		jTextArea.append("Panjang Kromosom: "+this.numFasilitas+"\n");
		
		int[]individuTerbaik		= ga.getIndividuTerbaik();
		double[][]solusi			= ga.getSolusi();
		
		tulisSolusiKeFileCSV(solusi);
		
		jTextArea.append("Individu Terbaik: |");
		for(int i=0;i<individuTerbaik.length;i++){
			jTextArea.append(" "+individuTerbaik[i]+" |");
		}	
		jTextArea.append("\n");
		jTextArea.append("Fitness Individu Terbaik: "+ga.getFitnessIndividuTerbaik()+"\n");
		jTextArea.append("-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- \n\n");
		jTextArea.append("S O L U  S I\n");
		jTextArea.append("(x,y)\n");
		for(int i=0;i<solusi.length;i++){
			jTextArea.append(1+i+". ("+solusi[i][0]+","+solusi[i][1]+")\n");
		}
		//go to panel hasil
		cardLayout.show(jPanel, "2");

		jButton1.setEnabled(true);
		jButton2.setEnabled(true);
		jButton3.setEnabled(true);
	}
	
	private void bacaParameter(){
		this.numFasilitas			= Integer.parseInt(jTextField1.getText().trim());
		this.numIndividu			= Integer.parseInt(jTextField2.getText().trim());
		this.numGenerasi			= Integer.parseInt(jTextField3.getText().trim());
		this.numIndividuTerseleksi	= Integer.parseInt(jTextField4.getText().trim());
		this.numCrossOverPoint		= Integer.parseInt(jTextField5.getText().trim());
		this.probabilitasMutasi		= Double.parseDouble(jTextField6.getText().trim());
		this.l						= Double.parseDouble(jTextField7.getText().trim());
		this.A0						= Double.parseDouble(jTextField8.getText().trim());
		this.k						= Double.parseDouble(jTextField9.getText().trim());
		this.CLamda					= Double.parseDouble(jTextField10.getText().trim());
	}
	
	private void tulisSolusiKeFileCSV(double[][]solusi){
		if(solusi!=null){
			FileWriter fw;
			BufferedWriter bw;
			
			try {
				fw	= new FileWriter(filecsvout);
				bw	= new BufferedWriter(fw);
		        bw.write("id,x,y");
				for(int i=0;i<solusi.length;i++){
					bw.newLine();
			        bw.write(1+i+","+solusi[i][0]+","+solusi[i][1]);
				}
				bw.close();
				fw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"
