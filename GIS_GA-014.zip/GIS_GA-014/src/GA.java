import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;


public class GA {

	private double data[][];
	
	/**
	  * @author : SUGIARTO COKROWIBOWO
	  * @author sugiartocokrowibowo@gmail.com
	  * @author +62852 5555 7738
	 **/
	
	private int numFasilitas;	
	private int[] elitism;
	private double fitnessElitism;
	private int numIndividu;
	private int numGenerasi;
	private int[][] generasi;
	private double[]fitness;
	private int numIndividuTerseleksi;
	private int numCrossoverPoint;
	private double probabilitasMutasi;
	
	private double l;
	private double A0;
	private double k;
	private double CLamda;
	
	private boolean isSet	= false;
		
	public GA(double[][]data, int numFasilitas, int numIndividu, int numGenerasi, int numIndividuTerseleksi, int numCrossOverPoint, double probabilitasMutasi, double l, double A0, double k, double CLamda) {
		super();
		this.initialize(data, numFasilitas, numIndividu, numGenerasi, numIndividuTerseleksi, numCrossOverPoint, probabilitasMutasi, l, A0, k, CLamda);
		this.prosesGenetika();
	}

	private void initialize(double[][]data, int numFasilitas, int numIndividu, int numGenerasi, int numIndividuTerseleksi, int numCrossOverPoint, double probabilitasMutasi, double l, double A0, double k, double CLamda){
		this.data					= data.clone();
		this.numFasilitas			= numFasilitas;
		this.elitism				= new int[this.numFasilitas];
		this.numIndividu			= numIndividu;
		this.generasi				= new int[this.numIndividu][this.numFasilitas];
		this.fitness				= new double[this.numIndividu];
		this.numGenerasi			= numGenerasi;
		this.numIndividuTerseleksi	= this.numIndividu;
		if(numIndividuTerseleksi<this.numIndividuTerseleksi){this.numIndividuTerseleksi	= numIndividuTerseleksi;}
		this.numCrossoverPoint		= 1 ;
		if(numCrossOverPoint>0&&numCrossOverPoint<numFasilitas){this.numCrossoverPoint		= numCrossOverPoint;}
		this.probabilitasMutasi		= 0;
		if(probabilitasMutasi>0&&probabilitasMutasi<=1){this.probabilitasMutasi		= probabilitasMutasi;}
		this.l						= l;
		this.A0						= A0;
		this.k						= k;
		this.CLamda					= CLamda;
		isSet						= true;
	}
	
	public void prosesGenetika(){
		if(isSet){
			//generate generasi awal
			for(int i=0;i<this.numIndividu;i++){
				int[]individu		= Utility.createIndividu(this.data, this.numFasilitas);
				this.generasi[i]	= individu.clone();
				this.fitness[i]		= Utility.hitungFitness(this.data, individu, this.l, this.A0, this.k, this.CLamda);
			}
			//sorting
			double[][]index	= Utility.sort(this.fitness);
			this.fitness	= Utility.getSortedFitness(index);
			this.generasi	= Utility.getSortedGenerasi(this.generasi, index);
			
			//inisialisasi elitism
			this.elitism	= this.generasi[0].clone();
			this.fitnessElitism	= this.fitness[0];
			Utility.saveGenerasiKeI("generasi_awal.csv", this.generasi, this.fitness, this.elitism, this.fitnessElitism);
			
			//memulai proses evolusi
			for(int g=0;g<this.numGenerasi;g++){
				//inisialisasi generasi baru
				int[][]generasiBaru	= new int[this.numIndividu][this.numFasilitas];
				
				//proses seleksi tournament
				for(int i=0;i<this.numIndividuTerseleksi;i++){
					generasiBaru[i]	= this.generasi[i].clone();
				}
				
				//proses crossover
				int h				= this.numIndividuTerseleksi;
				while(h<generasiBaru.length){
					int[]crossoverPoint	= Utility.getCrossoverPoint(this.numFasilitas, this.numCrossoverPoint);
					int indexOrangTua1	= Utility.rndInt(0, -1+this.numIndividu);
					int indexOrangTua2	= indexOrangTua1;
					while(indexOrangTua2==indexOrangTua1){
						indexOrangTua2	= Utility.rndInt(0, -1+this.numIndividu);
					}
					int[]orangTua1			= this.generasi[indexOrangTua1].clone();
					int[]orangTua2			= this.generasi[indexOrangTua2].clone();
					int[]anak1				= new int[this.numFasilitas]; 
					int[]anak2				= new int[this.numFasilitas]; 
					
					for(int i=0;i<this.numFasilitas;i++){
						if(crossoverPoint[i]==1){
							anak1[i]	= orangTua1[i];
							anak2[i]	= orangTua2[i];
						}else{

							anak1[i]	= orangTua2[i];
							anak2[i]	= orangTua1[i];
						}
					}
					
					if(h<generasiBaru.length){
						generasiBaru[h]	= anak1.clone();
						h++;
					}
					if(h<generasiBaru.length){
						generasiBaru[h]	= anak2.clone();
						h++;
					}
				}
				
				//proses mutasi
				for(int i=0;i<generasiBaru.length;i++){
					double rMutasi	= Utility.rndDouble(0, 1);
					if(rMutasi<=this.probabilitasMutasi){
						//lakukan mutasi rMutasi<probabilitas mutasi
						int titikMutasi					= Utility.rndInt(0, -1+this.numFasilitas);
						generasiBaru[i][titikMutasi]	= Utility.rndInt(0, -1+this.data.length);
					}
				}
				
				//validasi individu untuk memperbaiki duplikat gen
				for(int i=0;i<generasiBaru.length;i++){
					for(int m=1;m<this.numFasilitas;m++){
						boolean ganti	= false;
						for(int n=0;n<m;n++){
							if(generasiBaru[i][m]==generasiBaru[i][n]){
								//terdapat nilai kembar / duplikat
								ganti	= true;
								break;
							}
						}
						if(ganti){
							int iData		= Utility.rndInt(0, -1+this.data.length);
							boolean next	= false;
							while(!next){
								boolean gantiIData	= false;
								for(int n=0;n<this.numFasilitas;n++){
									if(n!=m&&iData==generasiBaru[i][n]){										
										iData		= Utility.rndInt(0, -1+this.data.length);
										gantiIData	= true;
										break;
									}
								}
								if(!gantiIData){
									generasiBaru[i][m]=iData;
									next	= true;
								}
							}
							
							
						}
					}
				}
				
				//set generasi dengan nilai dari generasiBaru
				for(int i=0;i<this.numIndividu;i++){
					this.generasi[i]	= generasiBaru[i].clone();
					this.fitness[i]		= Utility.hitungFitness(this.data, generasiBaru[i].clone(), this.l, this.A0, this.k, this.CLamda);
				}
				
				//sorting
				double[][]indexFitness	= Utility.sort(this.fitness);
				this.fitness			= Utility.getSortedFitness(indexFitness);
				this.generasi			= Utility.getSortedGenerasi(this.generasi, indexFitness);
				
				//evaluasi elitism
				if(this.fitness[0]>this.fitnessElitism){
					this.elitism		= this.generasi[0].clone();
					this.fitnessElitism	= this.fitness[0];
				}	
				Utility.saveGenerasiKeI("generasi_"+(1+g)+".csv", this.generasi, this.fitness, this.elitism, this.fitnessElitism);
			}
		}
	}
	
	
	
	public int[]getIndividuTerbaik(){
		int[] individuTerbaik	= null;
		if(this.elitism!=null){
			individuTerbaik	= this.elitism.clone();
			//sort individu terbaik
			for(int i=0;i<-1+individuTerbaik.length;i++){
				for(int j=1+i;j<individuTerbaik.length;j++){
					if(individuTerbaik[i]>individuTerbaik[j]){
						int tempIndividu	= individuTerbaik[i];
						individuTerbaik[i]	= individuTerbaik[j];
						individuTerbaik[j]	= tempIndividu;
					}
				}
			}
		}
		return individuTerbaik;
	}
	
	public double getFitnessIndividuTerbaik(){
		return this.fitnessElitism;
	}
	
	public double[][]getSolusi(){
		double[][]solusi		= null;
		int[] individuTerbaik	= getIndividuTerbaik();
		if(individuTerbaik!=null&&this.data!=null){
			solusi	= new double[individuTerbaik.length][2];
			for(int i=0;i<solusi.length;i++){
				solusi[i][0]	= this.data[individuTerbaik[i]][0];
				solusi[i][1]	= this.data[individuTerbaik[i]][1];
			}
		}
		return solusi;
	}
	
	public int getNumVertex(){
		return this.data.length;
	}	
	
}
